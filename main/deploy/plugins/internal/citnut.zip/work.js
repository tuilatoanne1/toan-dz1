const { random, round } = kb2abot.helpers;
const axios = require("axios");

module.exports = {
	
	name: "kiếm tiền",
	keywords:["work"],
	description: "bạn cần rất nhiều xu để tiêu xài đó",
	guide: "",
	hookType: "*",
	childs: [],

	permission: {
		'*': '*'
	},
	datastoreDesign: {
		account: {
			global: {
				xu: {},
				cooldown: {},
				cooldown_work: {}
			},
			local: {}
		},
		thread: {
			global: {},
			local: {}
		}
	},
	
	async onLoad() {
	},
	async onMessage(message, reply) {
		const storage = this.storage.account.global;

		if (!storage.xu) { storage.xu = {} };

		if (!storage.cooldown) { storage.cooldown = {} };

		if (!storage.cooldown_work) { storage.cooldown_work = {} };

		if (!storage.xu[message.senderID]) { storage.xu[message.senderID] = 0 };

		if (!storage.cooldown_work[message.senderID]) { storage.cooldown_work[message.senderID] = 0 }
	},

	async onCall(message, reply) {
		const storage = this.storage.account.global;
		let work_cooldown = storage.cooldown_work;

		function rep (msg) {
			fca.sendMessage(msg, message.threadID, message.messageID)
		};

		const time = new Date;

		axios({
			url: `https://raw.githubusercontent.com/Citnut/Citnut/main/KB2ABotECOConfig.json`,
			method: "GET",
			mode: "no-cors"
		}).then(res => {
			const data = res.data.data;

			if (time.getTime() < work_cooldown[message.senderID] + (data.cooldown.work * 1000)) {
				let cooldown = (work_cooldown[message.senderID] + (data.cooldown.work * 1000)) - time.getTime();
				rep(`vui lòng đợi ${round((cooldown/1000), 0)} giây để tiếp tục`)
			}else {
				work_cooldown[message.senderID] = time.getTime();
				let payout = round(random(data.work.min, data.work.max), 0);
				storage.xu[message.senderID] += payout;
				rep(`| +${payout} xu | ví của bạn có: ${storage.xu[message.senderID]} xu`)
			}
		})
	}
}

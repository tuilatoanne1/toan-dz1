const { random, round } = kb2abot.helpers;
const axios = require("axios");

module.exports = {
	
	name: "chộm cắp :))",
	keywords:["slut"],
	description: "bạn cần rất nhiều xu để tiêu xài đó",
	guide: "",
	hookType: "*",
	childs: [],

	permission: {
		'*': '*'
	},
	datastoreDesign: {
		account: {
			global: {
				xu: {},
				cooldown: {},
				cooldown_slut: {}
			},
			local: {}
		},
		thread: {
			global: {},
			local: {}
		}
	},
	
	async onLoad() {
	},
	async onMessage(message, reply) {
		const storage = this.storage.account.global;

		if (!storage.xu) { storage.xu = {} };

		if (!storage.cooldown) { storage.cooldown = {} };

		if (!storage.cooldown_slut) { storage.cooldown_slut = {} };

		if (!storage.xu[message.senderID]) { storage.xu[message.senderID] = 0 };

		if (!storage.cooldown_slut[message.senderID]) { storage.cooldown_slut[message.senderID] = 0 }
	},

	async onCall(message, reply) {
		const storage = this.storage.account.global;
		let slut_cooldown = storage.cooldown_slut;

		function rep (msg) {
			fca.sendMessage(msg, message.threadID, message.messageID)
		};

		const time = new Date;

		axios({
			url: `https://raw.githubusercontent.com/Citnut/Citnut/main/KB2ABotECOConfig.json`,
			method: "GET",
			mode: "no-cors"
		}).then(res => {
			const data = res.data.data;

			if (time.getTime() < slut_cooldown[message.senderID] + (data.cooldown.slut * 1000)) {
				let cooldown = (slut_cooldown[message.senderID] + (data.cooldown.slut * 1000)) - time.getTime();
				rep(`vui lòng đợi ${round((cooldown/1000), 0)} giây để tiếp tục`)
			}else {
				if (round(random(0, 100), 0) >= 80) {
					slut_cooldown[message.senderID] = time.getTime();
					let payout = round(random(data.slut.min, data.slut.max), 0);
					storage.xu[message.senderID] += payout;
					rep(`| +${payout} xu | ví của bạn có: ${storage.xu[message.senderID]} xu`)
				}else {
					slut_cooldown[message.senderID] = time.getTime();
					let payout = round(random(data.slut.min, data.slut.max), 0);
					storage.xu[message.senderID] -= payout;
					rep(`bạn đã bị công an bắt vì hoạt động kinh doanh trái phép tiền nộp phạt: ${payout} xu`)
				}
			}
		})
	}
}
